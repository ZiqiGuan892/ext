"""Avoid pinned-host allocation stalls when Ascend sleeps rollout weights."""
import gc
import os

from verl_omni_ext._patchkit import idempotent_patch


def sleep_with_pageable_backup(allocator, offload_tags, camem):
    torch = camem.torch
    cls = type(allocator)
    if offload_tags is None:
        offload_tags = (cls.default_tag,)
    elif isinstance(offload_tags, str):
        offload_tags = (offload_tags,)
    if not isinstance(offload_tags, tuple):
        raise TypeError("offload_tags must be a tuple or string")

    # Match upstream synchronization before any mapping is released. ACL memcpy
    # here is synchronous, and ordinary host memory passes the NPU round trip.
    torch.npu.synchronize()
    for ptr, data in allocator.pointer_to_data.items():
        if data.tag == cls.sleep_persistent_tag:
            continue
        handle = data.handle
        if data.tag in offload_tags:
            size = handle[1]
            backup = torch.empty(size, dtype=torch.uint8, device="cpu", pin_memory=False)
            status = camem.memcpy(backup.data_ptr(), size, ptr, size, 2)
            if status != 0:
                raise RuntimeError(f"Ascend sleep D2H backup failed: code={status}, bytes={size}")
            data.cpu_backup_tensor = backup
        camem.unmap_and_release(handle)
    gc.collect()
    torch.npu.empty_cache()


@idempotent_patch(
    name="qwen36_ascend_sleep_pageable",
    target_module="vllm_ascend.device_allocator.camem",
    target_attr="CaMemAllocator",
    fingerprint="Ascend CaMemAllocator with synchronous ACL memcpy",
    probe_signature=True,
)
def _patch_allocator(cls, __patch_signature__=None):
    import inspect
    from vllm_ascend.device_allocator import camem

    assert "offload_tags" in inspect.signature(cls.sleep).parameters
    assert hasattr(cls, "sleep_persistent_tag") and hasattr(cls, "wake_up")

    def sleep(self, offload_tags=None):
        return sleep_with_pageable_backup(self, offload_tags, camem)

    cls.sleep = sleep
    print("[qwen36-sleep] synchronous ACL backup uses pageable host memory", flush=True)
    return cls


def apply_pageable_sleep_patch():
    # Install only for explicitly enabled Qwen runs. Set 1 to restore upstream.
    if os.environ.get("MINICPMO_ASCEND_SLEEP_PIN_MEMORY", "1") != "0":
        return False
    return _patch_allocator()