"""Mandatory Huanyu IPC binding, resolved by the native worker factory.

Unlike registry-side best-effort imports, a worker_extension_cls import cannot
be skipped while continuing to start that worker. Keep the base __new__, LoRA,
sleep and wake APIs; only the full Huanyu weight-update method is replaced.
"""

import inspect
import os
import socket

from verl_omni.workers.rollout.vllm_rollout.utils import vLLMOmniColocateWorkerExtension

from .cache_precision import install_huanyu_cache_precision
from .processor_compat import install_huanyu_processor_compat
from .rollout_precision import install_huanyu_rollout_precision
from .weight_reload import bind_huanyu_weight_reload
from .precision_policy import report_policy
from .runtime_imports import report_native_source


class HuanyuColocateWorkerExtension(vLLMOmniColocateWorkerExtension):
    pass


report_policy("rollout-worker")
bind_huanyu_weight_reload(HuanyuColocateWorkerExtension)
if os.environ.get("HUANYU_JOB_DETERMINISM") == "1":
    from .job_determinism import install_job_determinism_check
    install_job_determinism_check()
if os.environ.get("HUANYU_TEXT_AB_DETERMINISM") == "1":
    from .ab_determinism import install_ab_determinism_check
    install_ab_determinism_check()
if os.environ.get("HUANYU_SERVE_REPEAT_DETERMINISM") == "1":
    from .repeat_determinism import install_repeat_determinism_check
    install_repeat_determinism_check()
# Some native checkouts do not execute the external-module registry gate in
# the spawned worker. The explicit worker factory must install these too,
# before it constructs the model. Installation errors propagate to startup.
install_huanyu_processor_compat()
install_huanyu_rollout_precision()
install_huanyu_cache_precision()
if os.environ.get("HUANYU_EMBEDDING_AB_DIR", "").strip():
    from .prompt_embedding_probe import install_runtime_probe
    install_runtime_probe()
report_native_source("inference-worker")
print(
    f"[huanyu-worker] explicit precision extension selected; host={socket.gethostname()} "
    f"pid={os.getpid()} source={__file__} "
    f"ipc_signature={inspect.signature(vLLMOmniColocateWorkerExtension.update_weights_from_ipc)}",
    flush=True,
)
