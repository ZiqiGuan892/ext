#!/usr/bin/env python3
"""Launch either side of a prepared AQA text comparison (no environment/Ray setup).

Python 3.8+. The case manifest is shared; standalone serving and verl validation
run sequentially when they use the same devices. No optimizer steps are taken.
"""

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import uuid


def serve_cli(argv):
    """Register the custom pipeline in the API process before native CLI dispatch.

    Worker external-module hooks may run after StageConfigFactory has already
    read the deploy file. Registration in a separate Python process would also
    be lost; invoke the native CLI in this same interpreter instead of exec().
    """
    if not argv or argv[0] != "serve":
        raise ValueError("internal serve entry requires the native serve arguments")
    registration = importlib.import_module("verl_omni_ext.models.qwen3_6_whisper.vllm_omni")
    registry = importlib.import_module("vllm_omni.config.pipeline_registry")
    pipeline = registration.QWEN36_WHISPER_THINKER_ONLY_PIPELINE
    # Explicit/idempotent even if the registration module was imported earlier.
    registry.register_pipeline(pipeline)
    print("[huanyu-text-ab] API pipeline registered: {}".format(pipeline.model_type), flush=True)
    native_cli = importlib.import_module("vllm.entrypoints.cli.main")
    source_reporter = importlib.import_module("verl_omni_ext.models.qwen3_6_huanyu.runtime_imports")
    source_reporter.report_native_source("serve-api")
    previous_argv = sys.argv
    try:
        sys.argv = ["vllm", *argv]
        return native_cli.main()
    finally:
        sys.argv = previous_argv


def load_case(directory):
    root = Path(directory).expanduser().resolve(strict=True)
    case = json.loads((root / "case.json").read_text(encoding="utf-8"))
    if case.get("schema_version") != 1:
        raise ValueError("unsupported comparison case schema")
    return root, case


def hydra_string(value):
    return json.dumps(str(value), ensure_ascii=False)


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_launch(root, case, project, mode, port=28889, served_model="qwen3.8", full_weight_audit_dir=None):
    """Return an argv/environment/deploy plan; never execute or import vLLM here."""
    sampling, engine = case["sampling"], case["engine"]
    repeat = bool(case.get("serve_repeat"))
    repeat_mode = (case.get("serve_repeat") or {}).get("determinism", "on")
    if repeat and repeat_mode not in ("on", "off"):
        raise ValueError("serve_repeat.determinism must be on or off")
    if repeat and mode != "serve":
        raise ValueError("serve-repeat cases test one serving engine; rollout launch is not supported")
    batch_invariant = engine.get("batch_invariant", False)
    if not isinstance(batch_invariant, bool):
        raise ValueError("engine.batch_invariant must be a boolean")
    if repeat and batch_invariant:
        raise ValueError("repeat requires batch_invariant=false; prepare a new repeat case with the current script")
    ab_mode = (case.get("determinism_check") or {}).get("mode", "on")
    if ab_mode not in ("on", "off"):
        raise ValueError("determinism_check.mode must be on or off")
    if not repeat and ab_mode == "off" and batch_invariant:
        raise ValueError("determinism=off requires batch_invariant=false")
    if full_weight_audit_dir is not None and mode != "rollout":
        raise ValueError("--full-weight-audit-dir is only supported for rollout (audit-only)")
    for key, expected in {"temperature": 0, "top_p": 1, "top_k": -1, "n": 1,
                          "repetition_penalty": 1, "frequency_penalty": 0,
                          "presence_penalty": 0, "min_tokens": 0, "ignore_eos": False}.items():
        if sampling.get(key) != expected:
            raise ValueError("comparison requires sampling.{}={!r}".format(key, expected))
    if engine["dtype"] != "bfloat16" or not isinstance(case["enable_thinking"], bool):
        raise ValueError("comparison requires BF16 and a boolean enable_thinking")
    checkpoint = str(case["model_path"])
    tp = int(engine["tensor_parallel_size"])
    if tp != 4:
        raise ValueError("this comparison launcher currently requires TP=4 on both sides")
    if not 1 <= port <= 65535 or not served_model.strip():
        raise ValueError("invalid port or served model name")
    examples = project / "examples/qwen3_6_huanyu"
    prompt_length = int(engine["prompt_length"])
    max_tokens = int(sampling["max_tokens"])
    context = int(engine["max_model_len"])
    seed = int(sampling["seed"])
    if prompt_length < 1 or max_tokens < 1 or context < prompt_length + max_tokens or not 0 <= seed < 2**63:
        raise ValueError("invalid prompt/response/context budget or seed")
    utilization = engine.get("gpu_memory_utilization")
    if type(utilization) not in (int, float) or not 0 < utilization <= 1:
        raise ValueError("engine.gpu_memory_utilization must be a number in (0, 1]")
    for key, expected in {"max_num_batched_tokens": context, "max_num_seqs": 1,
                          "enforce_eager": True}.items():
        if engine.get(key) != expected:
            raise ValueError("comparison requires engine.{}={!r}".format(key, expected))
    env = dict(os.environ)
    # Reused shells may still carry the old weight/tensor diagnostics. This run
    # compares only text and retains the normal initial Actor synchronization.
    disabled = (
        "HUANYU_CHECKPOINT_VALIDATION_MODE", "HUANYU_WEIGHT_SYNC_AUDIT_DIR",
        "HUANYU_FULL_WEIGHT_AUDIT_DIR", "HUANYU_FULL_WEIGHT_AUDIT_RUN_ID",
        "HUANYU_AUDIO_PROBE_DIR", "HUANYU_AUDIO_PROBE_ARM_FILE", "HUANYU_AUDIO_PROBE_FEATURE_ID",
        "HUANYU_EMBEDDING_AB_DIR", "HUANYU_EMBEDDING_AB_SIDE",
        "HUANYU_SERVE_REPEAT_DETERMINISM", "HUANYU_SERVE_REPEAT_DETERMINISM_MODE",
    )
    env.update({key: "" for key in disabled})
    embedding_check = case.get("embedding_check", {}).get("enabled", False)
    if not isinstance(embedding_check, bool):
        raise ValueError("embedding_check.enabled must be a boolean")
    logits_check = case.get("logits_check", {}).get("enabled", False)
    if not isinstance(logits_check, bool) or (logits_check and not embedding_check):
        raise ValueError("logits_check requires embedding_check.enabled=true")
    logits_top_k = case.get("logits_check", {}).get("top_k", 100)
    if type(logits_top_k) is not int or logits_top_k < 0:
        raise ValueError("logits_check.top_k must be a nonnegative integer (0=full)")
    forward_check = case.get("forward_check", {})
    if forward_check.get("enabled", False):
        steps = forward_check.get("max_steps")
        if (not logits_check or type(steps) is not int
                or not 1 <= steps <= case["logits_check"]["max_steps"]):
            raise ValueError("forward_check requires logits_check and a valid bounded max_steps")
        if forward_check.get("until_eos") and steps != max_tokens:
            raise ValueError("forward_check.until_eos requires max_steps=max_tokens")
    embedding_env = {
        "HUANYU_EMBEDDING_AB_DIR": str(root) if embedding_check and full_weight_audit_dir is None else "",
        "HUANYU_EMBEDDING_AB_SIDE": mode if embedding_check and full_weight_audit_dir is None else "",
    }
    env.update(embedding_env)
    # A/B determinism is independent of batch invariance. Inheriting the shell
    # here made standalone serve deterministic while Ray workers kept defaults.
    blocking = "0" if (repeat_mode if repeat else ab_mode) == "off" else "1"
    env.update({
        "PROJECT_ROOT": str(project), "MODEL_PATH": checkpoint,
        "HUANYU_PRECISION_PROFILE": "full", "HUANYU_GRAPH_MODE": "0",
        "ROLLOUT_TP": str(tp), "HUANYU_USE_PRECOMPUTE": "0", "MINICPMO_USE_PRECOMPUTE": "0",
        "HUANYU_EMBED_CACHE_DIR": "", "HUANYU_FREEZE_AUDIO": "true",
        "HUANYU_TRAIN_AUDIO_ENCODER": "false", "HUANYU_TRAIN_AUDIO_PROJECTOR": "false",
        "MINICPMO_TUNE_AUDIO": "0", "MINICPMO_TUNE_VISION": "0",
        "ENABLE_THINKING": "1" if case["enable_thinking"] else "0",
        "VLLM_ASCEND_WEIGHT_NZ_MODE": "0", "ASCEND_WEIGHT_NZ_MODE": "0",
        "ASCEND_ENABLE_TRANS_DATA_CACHE": "0",
        "VLLM_ASCEND_ENABLE_NZ": "0", "VLLM_WORKER_MULTIPROC_METHOD": "spawn",
        "VLLM_USE_V1": "0", "USE_OPTIMIZED_MODEL": "0", "MULTI_STREAM_MEMORY_REUSE": "2",
        "TASK_QUEUE_ENABLE": "0", "ASCEND_LAUNCH_BLOCKING": blocking,
        "HCCL_OP_EXPANSION_MODE": env.get("HCCL_OP_EXPANSION_MODE") or "AIV",
    })
    deterministic_env = {
        "HCCL_DETERMINISTIC": "true" if batch_invariant else "strict", "ASCEND_LAUNCH_BLOCKING": "1",
        "NCCL_DETERMINISTIC": "1", "LCCL_DETERMINISTIC": "1",
    }
    if repeat and repeat_mode == "off":
        # Preserve the separate repeat control experiment.
        deterministic_env.update(HCCL_DETERMINISTIC="false", ASCEND_LAUNCH_BLOCKING="0",
                                 NCCL_DETERMINISTIC="0", LCCL_DETERMINISTIC="0")
    if not repeat and ab_mode == "off":
        deterministic_env.update(HCCL_DETERMINISTIC="false", ASCEND_LAUNCH_BLOCKING="0",
                                 NCCL_DETERMINISTIC="0", LCCL_DETERMINISTIC="0")
    env.update(deterministic_env)
    env["HUANYU_TEXT_AB_DETERMINISM"] = "0" if repeat else "1"
    env["HUANYU_TEXT_AB_DETERMINISM_MODE"] = ab_mode
    env["HUANYU_TEXT_AB_SIDE"] = mode
    # Activate batch invariance through the actor engine's RL config. Setting
    # VLLM_BATCH_INVARIANT=1 in the shared Ray environment would also enable it
    # on GenRM, which has different cache/chunked-prefill settings. Clear stale
    # inherited flags; native Ascend sets it to 1 for the requested engine.
    env["VLLM_BATCH_INVARIANT"] = "0"
    if repeat:
        # The repeat experiment must not load incompatible batch-invariant
        # kernels, even when a reused shell previously enabled them.
        env["VLLM_BATCH_INVARIANT"] = "0"
        env["HUANYU_SERVE_REPEAT_DETERMINISM"] = "1"
        env["HUANYU_SERVE_REPEAT_DETERMINISM_MODE"] = repeat_mode
    env["HUANYU_TEXT_AB_BATCH_INVARIANT"] = "1" if batch_invariant else "0"
    # Optional arithmetic switches must not leak different shell defaults into
    # the two runs. full sets the remaining reference switches to one itself.
    for key in (
        "MINICPMO_HF_NORM_REFERENCE", "MINICPMO_HF_ROUTER_REFERENCE", "MINICPMO_HF_TEXT_ROPE_REFERENCE",
        "MINICPMO_MOE_MATCH_ROLLOUT", "MINICPMO_ISOLATE_FULL_ATTENTION",
        "MINICPMO_VISION_POSITION_REFERENCE", "MINICPMO_NATIVE_VISION_REFERENCE",
        "MINICPMO_MOE_TP_REFERENCE", "MINICPMO_ROW_TP_REFERENCE",
    ):
        env[key] = "0"
    # Both launch paths use the same source selector as environment preparation.
    native = (env.get("HUANYU_VLLM_SOURCE") or env.get("HUANYU_VLLM_OMNI_ROOT")
              or "/opt/huawei/dataset/infra_data/code/vllm-omni-xy-dbb-dev")
    env["HUANYU_VLLM_SOURCE"] = env["HUANYU_VLLM_OMNI_ROOT"] = native
    deploy = None
    if mode == "serve":
        old_paths = (
            "/vllm-workspace/vllm-omni",
            "/opt/huawei/dataset/ccb_data/code/hufenyu/vllm-omni-xy",
            "/opt/huawei/dataset/ccb/data/code/hufenyu/vllm-omni-xy",
            "/opt/huawei/dataset/hfy_guiyang/vllm-omni-xy-qwen-vit",
            "/opt/huawei/dataset/infra_data/code/vllm-omni-xy-qwen-vit",
        )
        retained = [p for p in env.get("PYTHONPATH", "").split(os.pathsep)
                    if p and p not in (native, str(project))
                    and not any(p == old or p.startswith(old + "/") for old in old_paths)]
        env["PYTHONPATH"] = os.pathsep.join([native, str(project)] + retained)
        env["HUANYU_TEXT_AB_DIR"] = ""  # AgentLoop capture is for verl only.
        extras = {
            "model_arch": "MiniCPMO50OmniForConditionalGeneration", "model_stage": "llm",
            "interleave_mm_strings": True,
            "limit_mm_per_prompt": {"image": 96, "audio": 64, "video": 1},
            "media_io_kwargs": {"video": {"fps": 1, "num_frames": 128}},
            "additional_config": {"weight_nz_mode": 0, "rl_config": {
                "enabled": True, "enable_batch_invariant": batch_invariant}},
            "worker_extension_cls": "verl_omni_ext.models.qwen3_6_huanyu.worker_extension.HuanyuColocateWorkerExtension",
        }
        engine_values = {
            "tensor_parallel_size": tp, "dtype": engine["dtype"],
            "max_model_len": context, "max_num_batched_tokens": context, "max_num_seqs": 1,
            "gpu_memory_utilization": utilization, "enforce_eager": True,
            "enable_prefix_caching": False, "enable_chunked_prefill": False,
            "mm_processor_cache_gb": 0, "seed": seed, "generation_config": "vllm",
        }
        if logits_check or repeat:
            engine_values["async_scheduling"] = False
        if batch_invariant:
            engine_values["block_size"] = 128
        # This is the same registered pipeline/stage/extras used by the Huanyu
        # rollout adapter. JSON is valid YAML and needs no YAML dependency.
        deploy = {"pipeline": "qwen3_6_whisper_thinker_only", "stages": [{
            "stage_id": 0, "devices": ",".join(str(i) for i in range(tp)),
            **engine_values, "engine_extras": extras,
            "default_sampling_params": dict(sampling, detokenize=True),
        }]}
        command = [
            "vllm", "serve", checkpoint, "--omni", "--port", str(port),
            "--served-model-name", served_model, "--trust-remote-code", "--stage-init-timeout", "600",
            "--deploy-config", str(root / "serve.deploy.yaml"), "--dtype", str(engine["dtype"]),
            "--tensor-parallel-size", str(tp), "--max-model-len", str(context),
            "--max-num-batched-tokens", str(context), "--max-num-seqs", "1",
            "--gpu-memory-utilization", str(utilization), "--seed", str(seed), "--enforce-eager",
            "--generation-config", "vllm", "--no-enable-prefix-caching", "--no-enable-chunked-prefill",
            "--mm-processor-cache-gb", "0", "--chat-template-content-format", "string",
            "--additional-config", json.dumps(extras["additional_config"], separators=(",", ":")),
            "--interleave-mm-strings", "--log-stats",
        ]
        if logits_check or repeat:
            command.append("--no-async-scheduling")
        if batch_invariant:
            command.extend(["--block-size", "128"])
        env["HUANYU_TEXT_AB_SERVE_LOG"] = str(root / "serve_console.log")
        shell = ('set -euo pipefail\n'
                 'source "$PROJECT_ROOT/examples/qwen3_6_huanyu/native_source.sh"\n'
                 'source "$PROJECT_ROOT/examples/qwen3_6_huanyu/graph_mode.sh"\n'
                 'source "$PROJECT_ROOT/examples/qwen3_6_huanyu/precision_mode.sh"\n'
                 'exec > >(tee -a "$HUANYU_TEXT_AB_SERVE_LOG") 2>&1\n'
                 'exec "$@"\n')
        # Re-enter this script only after the shell has installed the native
        # PYTHONPATH and precision policy. Do not lose registry state to exec.
        argv = ["bash", "-c", shell, "huanyu-text-ab-serve",
                sys.executable, str(Path(__file__).resolve()), "_serve_cli", *command[1:]]
    else:
        subset = str(case["subset_parquet"])
        env.update({
            "HUANYU_TEXT_AB_DIR": str(root), "TRAIN_FILE": subset, "VAL_FILE": subset,
            "HUANYU_AQA_TRAIN_FILE": subset, "HUANYU_AQA_VAL_FILE": subset,
            "NUM_NPUS": "16", "NNODES": "1", "RM_ENABLE": "1",
            "RM_N_GPUS_PER_NODE": "16", "RM_NNODES": "1", "RM_TP": "4", "RM_SPLIT_NODES": "1",
            "REWARD_POOL_NPUS": "16", "TRAIN_BATCH_SIZE": "4", "PPO_MINI_BATCH_SIZE": "4", "ROLLOUT_N": "4",
            "RM_MODEL_PATH": env.get("RM_MODEL_PATH") or "/opt/huawei/dataset/model_gy/downloaded_models/Qwen3.5-35B-A3B",
            "MAX_PROMPT_LENGTH": str(prompt_length), "ROLLOUT_PROMPT_LENGTH": str(prompt_length),
            "MINICPMO_MM_PROMPT_BUDGET": str(prompt_length), "MAX_RESPONSE_LENGTH": str(max_tokens),
            "ROLLOUT_MAX_MODEL_LEN": str(context), "MAX_TOKEN_LEN_PER_GPU": str(context),
            "ROLLOUT_TEMPERATURE": "0", "ROLLOUT_TOP_P": "1", "ROLLOUT_TOP_K": "-1",
            "ROLLOUT_REPETITION_PENALTY": "1", "ROLLOUT_FREQUENCY_PENALTY": "0", "ROLLOUT_PRESENCE_PENALTY": "0",
            "ROLLOUT_NUM_WORKERS": "4", "DEBUG_MODE": "0", "DEBUG_SAMPLES": "0",
            "TOTAL_TRAINING_STEPS": "1", "VAL_BEFORE_TRAIN": "true", "TEST_FREQ": "-1",
            "EXPERIMENT_NAME": "huanyu_aqa_text_ab", "HUANYU_SKIP_EDITABLE_INSTALL": "1",
            "RAY_ADDRESS": env.get("RAY_ADDRESS") or "auto",
        })
        command = ["bash", str(examples / "run_huanyu_aqa_audio_train.sh"),
                   "trainer.val_only=true", "trainer.val_before_train=true", "trainer.resume_mode=disable",
                   "trainer.save_freq=-1", "trainer.total_epochs=1", "data.shuffle=false",
                   "data.validation_shuffle=false", "data.val_batch_size=1", "data.train_max_samples=-1",
                   "data.val_max_samples=-1", "data.seed={}".format(seed), "actor_rollout_ref.rollout.load_format=safetensors",
                   "actor_rollout_ref.rollout.free_cache_engine=false", "actor_rollout_ref.rollout.dtype=bfloat16",
                   "actor_rollout_ref.rollout.max_num_seqs=1",
                   "actor_rollout_ref.rollout.gpu_memory_utilization={}".format(utilization),
                   "actor_rollout_ref.rollout.enable_chunked_prefill=false",
                   "actor_rollout_ref.rollout.enable_prefix_caching=false",
                   "actor_rollout_ref.rollout.agent.num_workers=4",
                   "actor_rollout_ref.rollout.agent.default_agent_loop=single_turn_agent",
                   "actor_rollout_ref.rollout.temperature=0", "actor_rollout_ref.rollout.top_p=1",
                   "actor_rollout_ref.rollout.top_k=-1", "actor_rollout_ref.rollout.ignore_eos=false",
                   "++actor_rollout_ref.rollout.repetition_penalty=1",
                   "actor_rollout_ref.rollout.val_kwargs.n=1", "actor_rollout_ref.rollout.val_kwargs.temperature=0",
                   "actor_rollout_ref.rollout.val_kwargs.top_p=1", "actor_rollout_ref.rollout.val_kwargs.top_k=-1",
                   "++actor_rollout_ref.rollout.engine_kwargs.q36_sampling.frequency_penalty=0",
                   "++actor_rollout_ref.rollout.engine_kwargs.q36_sampling.presence_penalty=0",
                   "++actor_rollout_ref.rollout.engine_kwargs.q36_sampling.min_tokens=0",
                   "++actor_rollout_ref.rollout.engine_kwargs.q36_sampling.seed={}".format(seed),
                   "actor_rollout_ref.rollout.seed={}".format(seed),
                   "++actor_rollout_ref.rollout.engine_kwargs.vllm_omni.generation_config=vllm",
                   "++actor_rollout_ref.rollout.engine_kwargs.vllm_omni.mm_processor_cache_gb=0",
                   "++data.apply_chat_template_kwargs.enable_thinking={}".format(str(case["enable_thinking"]).lower()),
                   "trainer.validation_data_dir=" + hydra_string(root / "validation_dump"),
                   "trainer.rollout_data_dir=" + hydra_string(root / "rollout_dump"),
                   "++ray_kwargs.ray_init.runtime_env.env_vars.HUANYU_TEXT_AB_DIR=" + hydra_string(root)]
        command.extend("++ray_kwargs.ray_init.runtime_env.env_vars.{}=\"\"".format(key) for key in disabled)
        if logits_check:
            command.append("++actor_rollout_ref.rollout.engine_kwargs.vllm_omni.async_scheduling=false")
        command.append("++actor_rollout_ref.rollout.engine_kwargs.vllm_omni.additional_config.rl_config.enable_batch_invariant="
                       + str(batch_invariant).lower())
        command.append("++actor_rollout_ref.rollout.engine_kwargs.vllm_omni.additional_config.rl_config.enabled=true")
        if batch_invariant:
            command.append("++actor_rollout_ref.rollout.engine_kwargs.vllm_omni.block_size=128")
        worker_env = dict(deterministic_env, ASCEND_LAUNCH_BLOCKING=blocking,
                          HUANYU_TEXT_AB_BATCH_INVARIANT=env["HUANYU_TEXT_AB_BATCH_INVARIANT"],
                          HUANYU_TEXT_AB_DETERMINISM=env["HUANYU_TEXT_AB_DETERMINISM"],
                          HUANYU_TEXT_AB_DETERMINISM_MODE=ab_mode,
                          HUANYU_TEXT_AB_SIDE=mode, VLLM_BATCH_INVARIANT="0")
        command.extend("++ray_kwargs.ray_init.runtime_env.env_vars." + key + "=" + hydra_string(value)
                       for key, value in worker_env.items())
        for key, value in embedding_env.items():
            prefix = "++ray_kwargs.ray_init.runtime_env.env_vars." + key + "="
            command = [arg for arg in command if not arg.startswith(prefix)]
            command.append(prefix + hydra_string(value))
        if full_weight_audit_dir is not None:
            audit_env = {
                "HUANYU_CHECKPOINT_VALIDATION_MODE": "sync",
                "HUANYU_FULL_WEIGHT_AUDIT_DIR": str(Path(full_weight_audit_dir).expanduser().resolve()),
                "HUANYU_FULL_WEIGHT_AUDIT_RUN_ID": uuid.uuid4().hex,
                "HUANYU_TEXT_AB_DIR": "",
            }
            env.update(audit_env)
            # Replace prior overrides so Hydra sees one value per key. No text
            # capture is allowed after the diagnostic reloads disk weights.
            prefixes = tuple("++ray_kwargs.ray_init.runtime_env.env_vars." + key + "=" for key in audit_env)
            command = [arg for arg in command if not arg.startswith(prefixes)]
            command.extend("++ray_kwargs.ray_init.runtime_env.env_vars." + key + "=" + hydra_string(value)
                           for key, value in audit_env.items())
        argv = command
    return {"mode": mode, "case_id": case["case_id"], "command": command,
            "argv": argv, "env": env, "deploy": deploy}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "_serve_cli":
        return serve_cli(argv[1:])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("serve", "rollout"))
    parser.add_argument("--case-dir", required=True)
    parser.add_argument("--project-root", default=os.environ.get("PROJECT_ROOT"))
    parser.add_argument("--port", type=int, default=28889)
    parser.add_argument("--served-model", default="qwen3.8")
    parser.add_argument("--full-weight-audit-dir", help="New directory for audit-only first-sync/disk comparison; stops before validation")
    parser.add_argument("--dry-run", action="store_true", help="Print the requested launch plan without starting processes")
    args = parser.parse_args(argv)
    try:
        if not args.project_root:
            raise ValueError("set PROJECT_ROOT or --project-root")
        root, case = load_case(args.case_dir)
        if (case.get("serve_repeat") or {}).get("wav_dir") and args.mode == "serve":
            if not case.get("model_path"):
                raise ValueError("this case targets an existing HTTP endpoint; to launch serve, prepare a new case with --model-path")
            if not (os.environ.get("HUANYU_VLLM_SOURCE") or os.environ.get("HUANYU_VLLM_OMNI_ROOT")):
                raise ValueError("set HUANYU_VLLM_SOURCE to this machine's Huanyu-enabled vLLM-Omni source directory")
        project = Path(args.project_root).expanduser().resolve(strict=True)
        plan = build_launch(root, case, project, args.mode, args.port, args.served_model, args.full_weight_audit_dir)
        print("[huanyu-text-ab] " + " ".join(shlex.quote(arg) for arg in plan["command"]), flush=True)
        notice = None
        if plan["env"]["HUANYU_TEXT_AB_DETERMINISM"] == "1" or case.get("serve_repeat"):
            batch_invariant = bool(case["engine"].get("batch_invariant"))
            notice = ("[huanyu-determinism] requested rl_config.enable_batch_invariant="
                      + str(batch_invariant).lower() + " VLLM_BATCH_INVARIANT="
                      + plan["env"].get("VLLM_BATCH_INVARIANT", "0") + " "
                      "HCCL_DETERMINISTIC=" + plan["env"]["HCCL_DETERMINISTIC"] + " "
                      "ASCEND_LAUNCH_BLOCKING=" + plan["env"]["ASCEND_LAUNCH_BLOCKING"] + " "
                      "NCCL_DETERMINISTIC=" + plan["env"]["NCCL_DETERMINISTIC"] + " "
                      "LCCL_DETERMINISTIC=" + plan["env"]["LCCL_DETERMINISTIC"] + " "
                      + ("ab_mode=" + plan["env"]["HUANYU_TEXT_AB_DETERMINISM_MODE"] + " "
                         if not case.get("serve_repeat") else "")
                      + ("repeat_mode=" + plan["env"]["HUANYU_SERVE_REPEAT_DETERMINISM_MODE"] + " "
                         if case.get("serve_repeat") else "")
                      + ("block_size=128 " if batch_invariant else "")
                      + "BS=1 graph=eager ab_worker_check=" + plan["env"]["HUANYU_TEXT_AB_DETERMINISM"]
                      + " repeat_worker_check="
                      + str(bool(case.get("serve_repeat"))).lower())
            print(notice, flush=True)
        if args.dry_run:
            return 0
        if not Path(case["model_path"]).is_dir() or not Path(case["subset_parquet"]).is_file():
            raise ValueError("prepared model path or subset Parquet is absent on this machine")
        if file_hash(case["subset_parquet"]) != case["subset_parquet_sha256"]:
            raise ValueError("prepared subset Parquet changed")
        if file_hash(root / "manifest.jsonl") != case["manifest_sha256"]:
            raise ValueError("prepared case manifest changed")
        for name, expected in case["checkpoint_file_sha256"].items():
            path = Path(case["model_path"]) / name
            if (file_hash(path) if path.is_file() else None) != expected:
                raise ValueError("checkpoint configuration changed: " + name)
        target = root / (args.mode + ".launch.json")
        if args.full_weight_audit_dir:
            audit_dir = Path(plan["env"]["HUANYU_FULL_WEIGHT_AUDIT_DIR"])
            audit_dir.mkdir(parents=True, exist_ok=False)
            target = audit_dir / "full_weights.launch.json"
            print("[huanyu-full-weight-audit] audit-only: expected_workers=16 tp_size=4; "
                  "no validation outputs; reports=" + str(audit_dir), flush=True)
        # Deliberately do not persist the ambient environment (it may contain credentials).
        snapshot = {key: value for key, value in plan.items() if key != "env"}
        snapshot["selected_environment"] = {
            key: plan["env"][key] for key in (
                "HUANYU_VLLM_SOURCE", "HUANYU_VLLM_OMNI_ROOT",
                "HUANYU_PRECISION_PROFILE", "HUANYU_GRAPH_MODE", "HCCL_OP_EXPANSION_MODE",
                "VLLM_ASCEND_WEIGHT_NZ_MODE", "USE_OPTIMIZED_MODEL",
                "HUANYU_TRAIN_AUDIO_ENCODER", "HUANYU_TRAIN_AUDIO_PROJECTOR",
                "HUANYU_FULL_WEIGHT_AUDIT_DIR", "HUANYU_FULL_WEIGHT_AUDIT_RUN_ID",
                "HUANYU_EMBEDDING_AB_DIR", "HUANYU_EMBEDDING_AB_SIDE",
                "HUANYU_SERVE_REPEAT_DETERMINISM", "HUANYU_SERVE_REPEAT_DETERMINISM_MODE",
                "HUANYU_TEXT_AB_DETERMINISM", "HUANYU_TEXT_AB_SIDE",
                "HUANYU_TEXT_AB_DETERMINISM_MODE",
            )
        }
        snapshot["selected_environment"].update({
            key: plan["env"].get(key) for key in ("PYTHONPATH", "VLLM_BATCH_INVARIANT", "HCCL_DETERMINISTIC",
                                                "ASCEND_LAUNCH_BLOCKING", "NCCL_DETERMINISTIC", "LCCL_DETERMINISTIC")
        })
        with target.open("x", encoding="utf-8") as stream:
            json.dump(snapshot, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        if plan["deploy"]:
            with (root / "serve.deploy.yaml").open("x", encoding="utf-8") as stream:
                json.dump(plan["deploy"], stream, ensure_ascii=False, indent=2)
                stream.write("\n")
            # The child installs tee only after this parent has printed the
            # request. Persist it explicitly, including in text-only repeat.
            if notice:
                with (root / "serve_console.log").open("a", encoding="utf-8") as stream:
                    stream.write(notice + "\n")
        return subprocess.call(plan["argv"], env=plan["env"])
    except (OSError, ValueError, KeyError) as exc:
        print("[huanyu-text-ab] ERROR: {}".format(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
