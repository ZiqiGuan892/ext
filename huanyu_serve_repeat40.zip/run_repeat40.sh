#!/usr/bin/env bash
# Run from an extracted bundle against an already running Huanyu API.
set -euo pipefail
bundle="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
repeat="$bundle/examples/qwen3_6_huanyu/repeat_huanyu_serve.py"
run="${REPEAT_ROOT:-$bundle/runs/huanyu_serve_repeat_$(date +%Y%m%d_%H%M%S)}"
python="${PYTHON_BIN:-python3}"

"$python" "$repeat" prepare --wav-dir "$bundle/audio" --output-dir "$run" \
  --samples row_000899 row_000418 --repeats 20 \
  --determinism off --batch-invariant false --logits-check false
printf '结果目录：%s\n' "$run"
"$python" "$repeat" request --case-dir "$run" \
  --url "${VLLM_URL:-http://localhost:28889/v1/chat/completions}" \
  --model "${SERVED_MODEL:-qwen3.8}" --timeout-s 3600
"$python" "$repeat" compare --case-dir "$run"
