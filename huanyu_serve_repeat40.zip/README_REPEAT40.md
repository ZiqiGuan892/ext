# Huanyu AQA 音频 repeat 测试（2 条 × 20 次）

在同一个 vLLM serve 进程上，按 `row_000899 → row_000418` 的顺序交替请求 20 轮。每次等上一条回复写盘后再发下一条，每条音频只和它自己的第 1 次结果比较。全程使用 4 张 NPU、TP=4、BS=1、`n=1`、贪心解码。本说明复现最近一次的纯文字配置，显式使用 `--determinism off --batch-invariant false --logits-check false`。需要开启确定性时，见最后一节。

## 1. 部署位置和运行环境

在原先能运行 Huanyu serve 的 Ascend Linux 环境中使用。ZIP 内的代码按服务器项目的相对路径放置，保留原文件内容和导入路径。服务器需要已有兼容的 Python、PyArrow、NumPy、CANN、torch/torch-npu、vLLM、vLLM-Ascend、vLLM-Omni、verl、verl-omni 及完整的 `verl_omni_ext` 基础项目。模型、WAV、原始 A/B case 和这些基础环境由服务器提供。本测试只启动独立 serve，不需要训练、GenRM 或手动启动 Ray 集群。

先把 ZIP 上传到服务器当前目录。以下命令列出清单，再把代码解压到原项目，`unzip` 遇到已有同名文件时会提示是否替换。

```bash
export PROJECT_ROOT=/opt/huawei/dataset/infra_data/code/verl_omni_qwen36_gzq_new
unzip -l huanyu_serve_repeat40.zip
test -d "$PROJECT_ROOT/verl_omni_ext/models/qwen3_6_whisper" &&
  unzip huanyu_serve_repeat40.zip -d "$PROJECT_ROOT"
```

| 路径 | 用途 |
|---|---|
| `$PROJECT_ROOT/examples/qwen3_6_huanyu/` | 命令入口。`repeat_huanyu_serve.py` 准备实验、发请求、比较；`launch_huanyu_aqa_text_ab.py` 启动 API 与 worker；`aqa_text_ab.py`、`request_aqa_validation_wav.py` 构造请求、校验 WAV、落盘回复。启动器在同一目录 source `native_source.sh`、`graph_mode.sh`、`precision_mode.sh`。这些文件应一起部署。 |
| `$PROJECT_ROOT/verl_omni_ext/models/qwen3_6_huanyu/` | 推理 worker 扩展、精度与处理器钩子、原生源码检查、repeat 确定性检查及可选 logits/embedding 探针。 |
| `$PROJECT_ROOT/verl_omni_ext/models/qwen3_6_whisper/vllm_omni/` | serve API 进程导入的共享 pipeline 注册入口。项目中其余通用扩展和基础包沿用已有安装。 |
| `HUANYU_VLLM_SOURCE=/opt/huawei/dataset/infra_data/code/vllm-omni-xy-dbb-dev` | 含 `vllm_omni/__init__.py` 和 `vllm_omni/model_executor/models/minicpmo_5_0/{huanyu_audio,minicpmo_5_0_omni_llm}.py` 的源码根目录。启动器把它放在 `PYTHONPATH` 首位。 |
| `AB_ROOT=$PROJECT_ROOT/runs/aqa_embedding_ab` | 之前用过的原始 A/B case，含 `case.json`、`manifest.jsonl`。必须同时含两条指定音频。若实际 case 在另一处，只调整 `AB_ROOT`。 |
| 原 case 的 `subset_parquet` | 准备时按 `case.json` 中记录的路径读取并校验 SHA-256；这是原 case 的子集 Parquet。 |
| 原 case 的 `export_dir` | WAV 导出根目录，先前使用 `/opt/huawei/dataset/infra_data/data/validation_vllm`。需保持 `samples/<源样本ID>/prompt.json`、`ground_truth.txt` 和清单记载的 WAV 可读。准备、请求、比较均需能访问原 WAV。 |
| 原 case 的 `model_path` | 本次历史实验为 `/opt/huawei/dataset/model_gy/downloaded_models/2748`。启动时从 case 读取 checkpoint。HTTP 名称 `qwen3.8` 是此模型在该服务中的别名。 |
| `REPEAT_ROOT=$PROJECT_ROOT/runs/huanyu_serve_repeat_<时间戳>` | 本次独立输出目录，由 `prepare` 创建。每次实验选新目录，两个终端用同一个绝对路径。 |
| `http://localhost:28889/v1/chat/completions` | 本机 serve 请求地址。终端 A 和 B 均开在这台服务器。 |

## 2. 终端 A · 准备 40 次请求

```bash
export PROJECT_ROOT=/opt/huawei/dataset/infra_data/code/verl_omni_qwen36_gzq_new
export HUANYU_VLLM_SOURCE=/opt/huawei/dataset/infra_data/code/vllm-omni-xy-dbb-dev
export AB_ROOT="$PROJECT_ROOT/runs/aqa_embedding_ab"
export REPEAT_ROOT="$PROJECT_ROOT/runs/huanyu_serve_repeat_$(date +%Y%m%d_%H%M%S)"
# 清除其他训练作业可能遗留的强制确定性开关，由本次 repeat 选择模式
export HUANYU_JOB_DETERMINISM=0
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3
EX="$PROJECT_ROOT/examples/qwen3_6_huanyu"

# 查看原 case 实际读取的路径、采样配置和两个源样本
python3 - <<'PY'
import json, os
from pathlib import Path
root = Path(os.environ["AB_ROOT"])
case = json.loads((root / "case.json").read_text(encoding="utf-8"))
for key in ("model_path", "subset_parquet", "export_dir", "prompt_mode", "sampling", "engine"):
    print(key, case[key])
rows = [json.loads(x) for x in (root / "manifest.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
for sid in ("row_000899", "row_000418"):
    row = next((r for r in rows if r["sample_id"] == sid), None)
    if row is None:
        raise SystemExit("原始 A/B case 缺少 " + sid)
    print(sid, row["wav_paths"])
PY

python3 "$EX/repeat_huanyu_serve.py" prepare \
  --source-case "$AB_ROOT" --output-dir "$REPEAT_ROOT" \
  --samples row_000899 row_000418 --repeats 20 \
  --determinism off --batch-invariant false --logits-check false
printf '请复制下一行到终端 B：\nexport REPEAT_ROOT=%q\n' "$REPEAT_ROOT"
```

确认准备输出为 `repeats=20 requests=40 BS=1 logits_check=False determinism=off`。原 case 的 `prompt_mode=system_audio` 时，HTTP 消息包含原 system prompt 与用户音频，用户问题描述和标准答案不会加入请求。模型、采样长度、seed、thinking 和显存利用率都以原 case 为准。

## 3. 终端 A · 启动并保持同一个 serve

确认 0–3 号 NPU 和 28889 端口可用。可先在以下启动命令末尾加 `--dry-run` 查看请求的配置，再执行实际命令。

```bash
python3 "$EX/launch_huanyu_aqa_text_ab.py" serve \
  --case-dir "$REPEAT_ROOT" --port 28889 --served-model qwen3.8
```

## 4. 终端 B · 确认 worker、发请求、比较

```bash
export PROJECT_ROOT=/opt/huawei/dataset/infra_data/code/verl_omni_qwen36_gzq_new
# 先粘贴终端 A 打印的 export REPEAT_ROOT=... 那一行
: "${REPEAT_ROOT:?请先设置终端 A 打印的 REPEAT_ROOT}"
EX="$PROJECT_ROOT/examples/qwen3_6_huanyu"

grep -nF '[huanyu-source]' "$REPEAT_ROOT/serve_console.log"
grep -nF 'actual scope=worker_init status=SETTINGS_VERIFIED' "$REPEAT_ROOT/serve_console.log"
curl -fsS http://localhost:28889/health
```

等 `/health` 返回 HTTP 200，并确认日志中 API 和 worker 的 `[huanyu-source]` 为 `VERIFIED`、`expected_root` 是选定源码目录。确定性日志看 4 个不同 TP rank 的 **actual** 行。off 模式应看到 `"mode": "off"`、`HCCL_DETERMINISTIC=false`、`ASCEND_LAUNCH_BLOCKING=0`、`NCCL_DETERMINISTIC=0`、`LCCL_DETERMINISTIC=0` 和 `VLLM_BATCH_INVARIANT=0`。只有 `requested` 表示启动器已设置参数，尚缺 worker 确认。

```bash
python3 "$EX/repeat_huanyu_serve.py" request \
  --case-dir "$REPEAT_ROOT" \
  --url http://localhost:28889/v1/chat/completions \
  --model qwen3.8 --timeout-s 3600

python3 "$EX/repeat_huanyu_serve.py" compare --case-dir "$REPEAT_ROOT"
```

## 5. 查看两条音频各自的 20 次结果

- `$REPEAT_ROOT/manifest.jsonl` 将唯一调用 ID 映射到 `source_sample_id` 和 `repetition`。例如 `row_000000` 对应 899 的第 1 次，`row_000001` 对应 418 的第 1 次，`row_000002` 对应 899 的第 2 次。
- `$REPEAT_ROOT/serve/row_*.txt` 是每次的回复正文；同名 `.json` 包含请求摘要、原始 HTTP 响应、单独返回的推理文本和结束原因。
- `$REPEAT_ROOT/serve.launch.json`、`serve.deploy.yaml` 和 `serve_console.log` 分别记录启动计划、部署配置和实际日志。启动或请求中断后应另建 repeat 目录重试，以保留已有结果。
- `$REPEAT_ROOT/repeat_summary.json` 给出整组结论及每次与同一音频第 1 次的比较结果。

```bash
python3 - <<'PY'
import json, os
from pathlib import Path
r = json.loads((Path(os.environ["REPEAT_ROOT"]) / "repeat_summary.json").read_text(encoding="utf-8"))
print(r["status"], "expected_requests", r["expected_requests"], "logits", r["logits_status"])
for s in r["samples"]:
    print(s["sample_id"], s["status"], "complete", s["complete_http_responses"],
          "text_variants", s["distinct_text_variants"], "match_first", s["matching_baseline_text_requests"])
PY
```

每条的 `complete=20, text_variants=1, match_first=20` 表示 20 次回复及单独的推理文本均相同，计数含第 1 次。总状态 `PASS`（退出码 0）还要求结束原因和截断标志一致。`DIFFERENT`（1）可在对应的 `repetitions` 中查看 `text_exact_equal` 和 `termination_equal`；`INCOMPLETE`（2）可查看 `issues` 和 `errors`。本模式的 `logits_status=NOT_COLLECTED`。该报告衡量同一音频重复生成的稳定性，不衡量答案正确率或 serve 与 verl rollout 的一致性。

## 可选 · 用同样的 40 条请求测试确定性开启

首次准备时可直接用 `--determinism on`。若已有上述 off 实验，可在终端 A 停掉该实验的 serve，复制原 repeat 的配置创建独立对照，继续使用相同的 WAV、prompt 和顺序。

```bash
export CONTROL_ROOT="${REPEAT_ROOT}_deton_$(date +%Y%m%d_%H%M%S)"
python3 "$EX/repeat_huanyu_serve.py" control \
  --case-dir "$REPEAT_ROOT" --output-dir "$CONTROL_ROOT" --determinism on
export REPEAT_ROOT="$CONTROL_ROOT"
printf 'export REPEAT_ROOT=%q\n' "$REPEAT_ROOT"
```

按第 3–5 节重跑，两终端都改用新打印的目录。on 模式的 worker 日志应为 `"mode": "on"`、HCCL 为 `strict`、ASCEND_LAUNCH_BLOCKING/NCCL/LCCL 均为 `1`。两种模式都保持 `VLLM_BATCH_INVARIANT=0` 和贪心解码。另需检查 logits 时，在新 case 的 `prepare` 中改用 `--logits-check true --logits-top-k 100`，会同时采集 embedding，额外占用存储；此时请直接阅读 `repeat_summary.json` 的 logits 字段，第 5 节的简表专用于纯文字模式。
