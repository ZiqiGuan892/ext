# Huanyu Serve 音频重复测试 · 2 条 × 20 次

## 把 WAV 放在哪里

解压 ZIP，进入含本说明的目录。把已准备好的两条音频放到下面两个位置。两条源音频都叫 `audio_00.wav` 也可以，复制时分别改成对应的样本名。

```text
解压目录/
├── audio/
│   ├── row_000899.wav    # “央求”这条
│   └── row_000418.wav    # “新疆的车牌号”这条
├── examples/qwen3_6_huanyu/
└── README_REPEAT40.md
```

请使用非空、完整的 PCM16 WAV。程序保留原 WAV 的字节、采样率和声道。每次实验的 `case.json`、清单和小型 Parquet 都在本机生成，不需要原 A/B 目录、共享数据盘、旧 Parquet 或标准答案。准备和比较期间请保持这两个 WAV 在原位置。

## 用已启动的 Huanyu serve 测试

在解压目录运行以下命令。客户端需要 Python 3 和 PyArrow（`python3 -c 'import pyarrow'` 可检查）。假设服务在本机 28889 端口，模型别名为 `qwen3.8`；如果同事的服务地址或别名不同，用 `VLLM_URL`、`SERVED_MODEL` 指定。可通过 `VLLM_API_KEY` 提供鉴权。

```bash
bash run_repeat40.sh
```

服务地址或模型别名不同时可以覆盖：

```bash
VLLM_URL=http://localhost:28889/v1/chat/completions SERVED_MODEL=qwen3.8 bash run_repeat40.sh
```

两条样本交替发送，每次等待上一条结果写盘，共 40 个带唯一 ID 的 HTTP 请求。每个请求发送相同的中文 system prompt 和当前样本的音频，`n=1`、`temperature=0`、`top_p=1`、`top_k=-1`、`seed=42`、`max_tokens=2048`、开启 thinking。客户端一次只有一个在途请求。要控制服务实际批量，需要使用专用服务，启动时设置 `max_num_seqs=1`。服务需支持请求中的 `audio_url`、`request_id` 及采样字段，并在响应 ID 中保留请求 ID。目标是已有服务时，`--determinism off` 记录实验选择；worker 实际环境由服务启动方式决定。

## 如需由测试包启动 serve

这条路径用于核验 TP=4、BS=1、确定性开关等服务端设置。需要 4 张可用 NPU、兼容的 Ascend/vLLM 环境、完整 Huanyu 扩展工程、本机模型权重，以及本机适配过 Huanyu 的 vLLM-Omni 源码。在完整扩展项目根目录解压本 ZIP，使 `examples/` 和 `verl_omni_ext/` 合并到对应目录，再在该目录的 `audio/` 放两个 WAV。先在终端 A 设置 `MODEL_PATH` 和 `HUANYU_VLLM_SOURCE` 为这台机器的实际绝对路径。

```bash
# 终端 A，当前目录是刚刚解压到的完整项目
export PROJECT_ROOT="$(pwd -P)"
EX="$PROJECT_ROOT/examples/qwen3_6_huanyu"
: "${MODEL_PATH:?请先 export MODEL_PATH 为本机含 config.json 的 Huanyu checkpoint 目录}"
: "${HUANYU_VLLM_SOURCE:?请先 export HUANYU_VLLM_SOURCE 为本机含 vllm_omni 的源码根目录}"
export HUANYU_JOB_DETERMINISM=0 ASCEND_RT_VISIBLE_DEVICES=0,1,2,3
export REPEAT_ROOT="$PROJECT_ROOT/runs/huanyu_serve_repeat_$(date +%Y%m%d_%H%M%S)"

python3 "$EX/repeat_huanyu_serve.py" prepare \
  --wav-dir "$PROJECT_ROOT/audio" --output-dir "$REPEAT_ROOT" \
  --model-path "$MODEL_PATH" --repeats 20 \
  --determinism off --batch-invariant false --logits-check false &&
  printf '请复制到终端 B：\nexport REPEAT_ROOT=%q\n' "$REPEAT_ROOT" &&
  python3 "$EX/launch_huanyu_aqa_text_ab.py" serve \
    --case-dir "$REPEAT_ROOT" --port 28889 --served-model qwen3.8
```

`HUANYU_VLLM_SOURCE` 指向含 `vllm_omni/__init__.py`、Huanyu 原生音频模块和 NPU worker 的源码根目录。启动器加载 `native_source.sh`、`graph_mode.sh`、`precision_mode.sh`。本地 WAV 模式从本机路径启动，默认显存利用率 0.9；如需对齐旧 case 的 0.5，在 `prepare` 加 `--gpu-memory-utilization 0.5`。要测试确定性开启，用新的结果目录，将 `--determinism off` 改为 `on`，保持 `--batch-invariant false`。

```bash
# 终端 B，同一台服务器、同一项目目录，先粘贴终端 A 打印的 export REPEAT_ROOT=...
: "${REPEAT_ROOT:?请使用终端 A 打印的结果目录}"
EX="$(pwd -P)/examples/qwen3_6_huanyu"
grep -F '[huanyu-source]' "$REPEAT_ROOT/serve_console.log"
grep -F 'actual scope=worker_init status=SETTINGS_VERIFIED' "$REPEAT_ROOT/serve_console.log"
curl -fsS http://localhost:28889/health
```

等服务就绪，核对 4 个 TP rank 的 actual 记录，其 `mode` 应与所选 `on/off` 一致，`VLLM_BATCH_INVARIANT` 应为 `0`。然后执行：

```bash
python3 "$EX/repeat_huanyu_serve.py" request \
  --case-dir "$REPEAT_ROOT" --url http://localhost:28889/v1/chat/completions \
  --model qwen3.8 --timeout-s 3600 &&
python3 "$EX/repeat_huanyu_serve.py" compare --case-dir "$REPEAT_ROOT"
```

## 在哪里看结果

| 相对本次 `REPEAT_ROOT` 的路径 | 用途 |
|---|---|
| `case.json`、`manifest.jsonl`、`validation.parquet` | 本机生成的配置、输入摘要和调用映射。清单中的 `source_sample_id`、`repetition` 可定位每一次请求。 |
| `serve/row_*.txt`、`serve/row_*.json` | 每次回复正文，以及对应的请求摘要、原始响应和终止状态。 |
| `repeat_summary.json` | 每条音频的 20 次回复分别和自己的第 1 次比对。完整且相同为 `PASS`，文字或终止状态不同为 `DIFFERENT`，缺失或校验失败为 `INCOMPLETE`。退出码分别为 0、1、2。 |
| `serve_console.log`、`serve.launch.json`、`serve.deploy.yaml` | 由本包启动 serve 时的真实进程日志、启动配置、部署配置。 |

纯文字测试每条应有 `complete_http_responses=20`。`distinct_text_variants=1` 且 `matching_baseline_text_requests=20` 表示这 20 次正文及单独返回的 reasoning 一致。总 `PASS` 还要求 `finish_reason` 和截断标志相同。`logits_status=NOT_COLLECTED` 表示本次没有比较 logits。重复性和答案正确率是不同指标。

输入缺失或格式错误会提示具体 WAV 路径；输入在准备后改变会被 SHA-256 校验发现。若服务中断或需要重新准备，选择新的 `REPEAT_ROOT`。原先已有 A/B case 的用户仍可使用旧的 `prepare --source-case ...` 入口。
